<?php
session_start();

$host = "localhost";    /* Host name */
$user = "root";         /* User */
$password = "";         /* Password */
$dbname = "servicios";   /* Database name */

// Create connection
$conn = mysqli_connect($host, $user, $password,$dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/* change character set to utf8 */
if (!$conn->set_charset("utf8")) {
    printf("Error loading character set utf8: %s\n", $conn->error);
    exit();
} else {
    //printf("Current character set: %s\n", $conn->character_set_name());
}


function limpiarCadena($str)
{
	global $conn;
	$str = stripslashes($str);
	$str = mysqli_real_escape_string($conn,trim($str));
	return htmlspecialchars($str);
}


//extraer decimales de texto
 function normalizeDecimal($val){ 
    if (isset($val) == False || ($val == "") || strlen($val) == 1 ) {
      return "0.00";
    }
    if (is_numeric($val)){
        //echo "is_numeric";
        $val = (string) $val;
    }
    $input = str_replace(' ', '', $val); 
    $number = str_replace(',', '.', $input); 
    //echo "<br>";  echo $number;
    if (strpos($number, '.')) { 
        $groups = explode('.', str_replace(',', '.', $number)); 
        //echo "<br>"; echo var_dump($groups);
        $lastGroup =  intval(preg_replace('/[^0-9]+/', '', array_pop($groups)), 10); 
        $numberString = intval(preg_replace('/[^0-9]+/', '', implode('', $groups)), 10);  
        $number = $numberString. '.' . $lastGroup; 
    } else{
        $number = intval(preg_replace('/[^0-9]+/', '', $number), 10);
    }
    //echo "<br> resulto:"; echo $number;
    return $number; 
}

?>