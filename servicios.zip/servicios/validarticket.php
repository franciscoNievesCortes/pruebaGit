
<?php
header('Content-Type: text/html; charset=utf-8');

require('fpdf/fpdf.php');

//$pdf = new FPDF();
$pdf = new FPDF($orientation='P',$unit='mm', array(45,350));

$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'¡Hola, Mundo!');
$pdf->Output();
?>
