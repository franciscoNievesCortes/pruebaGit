<?php
	session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
<head>
	<title>Validando...</title>
	<meta charset="utf-8">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
</head>
</head>
<body>
<?php
	include "../bd/conexion.php";
 	echo("conectando...");
 	if(isset($_POST['login'])){
		$user = $_POST['user'];
		$pw = $_POST['pw'];
		
       	$log = $conn->query("SELECT id_caja, usuario_caja, usuario_token,type_user FROM caja WHERE usuario_caja='$user'");
       	$row_cnt = $log->num_rows;
		//printf("Result set has %d rows.\n", $row_cnt);
		if ($row_cnt>0){
			$type_usuario = "";
			while($row = mysqli_fetch_array($log) ){
		        $_SESSION["user"] = $row['usuario_caja']; 
		        $_SESSION["userid"] = $row['id_caja']; 
		        $_SESSION["type_user"] = $row['type_user']; 
		        //$_SESSION["cierre_id"]= 0;
				$type_usuario = $row['type_user'];
				echo "$type_usuario";
				break;
		    }
		    $hash = $row['usuario_token']; //Es el hash guardado en la BD, lo obtengo mediante una consulta $passHash = password_hash('pass', PASSWORD_BCRYPT);
			if(password_verify($pw,$hash)) {
				echo "verificado";
				if ($type_usuario =='Administrador') {
					echo '<script> window.location="../index.php"; </script>';
				}else{
					echo '<script> window.location="../index.php"; </script>';
				}
			}else{
			  echo '<script> window.location="index.php?msj=validar"; </script>';		
			}


		}else{
		  echo '<script> window.location="index.php?msj=no-encontrado"; </script>';		
		}


	}
	mysqli_close($conn);
	echo ".ok";

   ?>	
</body>
</html>