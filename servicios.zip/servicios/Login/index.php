<?php

  session_start();

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="description" content="">

  <meta name="author" content="Dashboard">

  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

  <title>Control de servicios</title>



  <!-- Favicons -->

  <link href="favicon.png" rel="icon">

  <!-- Bootstrap core CSS -->

  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!--external css-->

  <link href="../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />

  <!-- Custom styles for this template -->

  <link href="../css/style.css" rel="stylesheet">

  <link href="../css/style-responsive.css" rel="stylesheet">

 </head>



<body>

   



<div  align="center">

        <h2>Control de Servicios</h2>

    </div>



  <div id="login-page">

       

      

    <div class="container">

      <form class="form-login" method="post" action="validar.php">

        <h2 class="form-login-heading">Iniciar sesión</h2>

        <div class="login-wrap">

          <input type="text" name="user" class="form-control" placeholder="Usuario" autofocus required="">

          <br>

          <input type="password" name="pw" class="form-control" placeholder="Contraseña" required="">

          <br>

          <br>

         

          <button class="btn btn-theme btn-block" href="index.html" type="submit" name="login"><i class="fa fa-lock"></i> Entrar</button>
          <br>

         <div align="center">

            <a href="restablecer_pass.php">Recuperar contraseña</a>           
         </div>

        

        </div>

     

      </form>

    </div>

  </div>

  <!-- js placed at the end of the document so the pages load faster -->

  <script src="../lib/jquery/jquery.min.js"></script>

  <script src="../lib/bootstrap/js/bootstrap.min.js"></script>

  

</body>



</html>

