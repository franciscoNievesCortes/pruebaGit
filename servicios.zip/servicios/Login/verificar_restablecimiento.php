<?php  



include "../bd/conexion.php";

$usuario = $_POST['user'];
$pass1 = $_POST['pass1'];
$pass2 = $_POST['pass2'];
$passHash = password_hash($pass2, PASSWORD_BCRYPT);

$log = $conn->query("SELECT usuario_caja, usuario_token,type_user FROM caja WHERE usuario_caja='$usuario'");
$row_cnt = $log->num_rows;
//printf("Result set has %d rows.\n", $row_cnt);
if ($row_cnt>0){
	while($row = mysqli_fetch_array($log) ){
		
		$resp = $conn->query("UPDATE caja SET  usuario_token = '$passHash'  WHERE usuario_caja = '$usuario' ");
		echo"<SCRIPT> alert ('La contraseña se ha restablecido correctamente');
		document.location=('index.php');
		</SCRIPT>";
		break;
	}
	

}else{
	echo '<script> window.location="index.php?msj=no-encontrado"; </script>';	
}
mysqli_close($conn);
