<?php

  session_start();

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="description" content="">

  <meta name="author" content="Dashboard">

  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

  <title>Restablecer Contraseña</title>



  <!-- Favicons -->

  <link href="../img/favicon.png" rel="icon">

  <link href="../img/apple-touch-icon.png" rel="apple-touch-icon">



  <!-- Bootstrap core CSS -->

  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!--external css-->

  <link href="../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />

  <!-- Custom styles for this template -->

  <link href="../css/style.css" rel="stylesheet">

  <link href="../css/style-responsive.css" rel="stylesheet">


  <style type="text/css">
      .confirmacion{background:#C6FFD5;border:1px solid green;}
      .negacion{background:#ffcccc;border:1px solid red}

    </style>

 </head>



<body>

   



<div  align="center">

        <h2>Control de cobros</h2>

    </div>



  <div id="login-page">

       

      

    <div class="container">

      <form class="form-login" method="post" action="verificar_restablecimiento.php">

        <h2 class="form-login-heading">Restablecer Contraseña</h2>

        <div class="login-wrap">

          <input type="text" name="user" class="form-control" placeholder="Usuario" autofocus required="">

          <br>

          <br>

          <input type="password" name="pass1" id="clavea"  class="form-control" placeholder="Nueva Contraseña" required="">

          <br>

          <br>

         <input type="password" name="pass2" id="clavea"  class="form-control" placeholder="Repite Contraseña" required="">


          <br>

          <br>

          <button class="btn btn-theme btn-block" href="index.html" type="submit" name="login"><i class="fa fa-lock"></i> Entrar</button>
          <br>

         
        

        </div>

     

      </form>

    </div>

  </div>

  <!-- js placed at the end of the document so the pages load faster -->

  <script src="../lib/jquery/jquery.min.js"></script>

  <script src="../lib/bootstrap/js/bootstrap.min.js"></script>

  <!--BACKSTRETCH-->

  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->

  <script type="text/javascript" src="../lib/jquery.backstretch.min.js"></script>

  <script>

    $.backstretch("img/login-bg.jpg", {

      speed: 500

    });

  </script>

</body>


<script type="text/javascript">
       

       $(document).ready(function() {
  //variables
  var pass1 = $('[name=pass1]');
  var pass2 = $('[name=pass2]');
  var confirmacion = "Las contraseñas si coinciden";
  var longitud = "La contraseña debe estar formada entre 6-10 carácteres (ambos inclusive)";
  var negacion = "No coinciden las contraseñas";
  var vacio = "La contraseña no puede estar vacía";
  //oculto por defecto el elemento span
  var span = $('<span></span>').insertAfter(pass2);
  span.hide();
  //función que comprueba las dos contraseñas
  function coincidePassword(){
  var valor1 = pass1.val();
  var valor2 = pass2.val();
  //muestro el span
  span.show().removeClass();
  //condiciones dentro de la función
  if(valor1 != valor2){
  span.text(negacion).addClass('negacion'); 
  }
  if(valor1.length==0 || valor1==""){
  span.text(vacio).addClass('negacion');  

  }
  if(valor1.length<6 || valor1.length>10){
  span.text(longitud).addClass('negacion');
  }
  if(valor1.length!=0 && valor1==valor2){
  span.text(confirmacion).removeClass("negacion").addClass('confirmacion');
  }
  }
  //ejecuto la función al soltar la tecla
  pass2.keyup(function(){
  coincidePassword();
  });
});
     </script>



</html>

