<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Servicios</a>
    </div>
    <ul class="nav navbar-nav" >
      <li class="active"><a href="index.php">Home</a></li>
      <li><a data-toggle="modal" href="#modalservicio" onclick="validar_dialog('modalservicio')">Alta de servicio</a></li>

      <li><a data-toggle="modal" href="#modal_cliente" onclick="validar_dialog('modal_cliente')">Alta de cliente</a></li>

      <li><a data-toggle="modal" href="#modaladd_servicio" onclick="validar_dialog('modaladd_servicio')">Alta de servicios a clientes</a></li>

      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Caja
        <span class="caret"></span></a>
        <ul class="dropdown-menu" >
          <li><a data-toggle="modal" href="#modal_abrircaja" 
                  onclick="validar_dialog('modal_abrircaja')">Abrir caja</a></li>
          <li><a data-toggle="modal" onclick="validar_dialog('modal_abrircaja'); return cerrarcja();">Cerrar caja</a></li>
          <li><a href="cajas_usuario.php">Usar otra caja</a></li>
          <li><hr style="margin: 5px;"></li>
          <li><a href="index.php">Nuevo pago</a></li>
          <li><a href="historial_pagos.php">Historial de pagos</a></li>
        </ul>
      </li>
      <li><a  href="Login/logout.php">Cerrar Sesion</a></li>

    </ul>
  </div>
</nav>

<script type="text/javascript">
    function validar_dialog(lk_menu){  
      if(document.getElementById(lk_menu) == undefined && lk_menu.length < 20){
        if (confirm('Abrir ventana de pagos, y vuelva a intentar?')) {
            // Save it!
            window.location.href = 'index.php';
        }
      }
    }
</script>