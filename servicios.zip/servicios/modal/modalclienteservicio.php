<?php
include "../bd/conexion.php";
?>

 <!-- Modal -->
<div class="modal fade" id="modaladd_servicio" tabindex="-1" role="dialog" aria-labelledby="modalservicio" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h3 class="modal-title">Registrar Nuevo Servicio a Clientes</h3>
            </div>
            <div class="modal-body">
                <form name="formulario" id="formulario" action="controlador/guardar_serviciocliente.php" method="POST" autocomplete="off" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-6 col-sm-9 col-xs-12">
                            <label>Cliente</label>
                            <select name="cs_selectcliente" id="cs_selectcliente" class="form-control selectpicker" data-live-search="true" required></select>
                        </div>
                        <div class="form-group col-sm-6 col-xs-12">
                            <label>Servicios</label>
                            <select name="cs_selectservicio" id="cs_selectservicio" class="form-control selectpicker" data-live-search="true" required></select>
                        </div>
                        <div class="form-group col-sm-6 col-xs-12 col-sm-offset-6 ">
                            <label>Número servicio</label>
                            <input type="text" name="cs_numero_servicio" class="form-control" required>
                        </div>
                    </div>

                    <div align="center">
                        <button type="submit" class="btn btn-primary">Registrar</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">

$(document).ready(function () {

  //Cargamos los items al select Clientes
  $.post("Ajax/servicios.php?op=selectCliente", function(r){
          $("#cs_selectcliente").append(r);
          $('#cs_selectcliente').selectpicker('refresh');
  });
  
  //Cargamos los items al select Servicios
  $.post("Ajax/servicios.php?op=selectServicios ", function(r){
          $("#cs_selectservicio").append(r);
          $('#cs_selectservicio').selectpicker('refresh');
  });

});

</script>
