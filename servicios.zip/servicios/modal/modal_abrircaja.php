<!-- Modal -->
<div class="modal fade" id="modal_abrircaja" tabindex="-1" role="dialog" aria-labelledby="modalabrircaja" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h3 class="modal-title" id="modalabrircaja">
                   Abrir caja</h3>
                <p>Cajero: <?php   echo "<strong>".$_SESSION["user"] ."</strong>"; 
                  if(isset($_SESSION["cierre_id"])){
                    echo " _Folio: <strong>" .date('YCJ-'). $_SESSION["cierre_id"]."</strong>";
                  } /*$_SESSION["cierre_id"]=0;*/?></p>
            </div>
            <div class="modal-body" style="margin-left: 3rem;">
                <!-- Form metodo de pago -->
                <form action="controlador/accion_caja_abrir.php" id="form_abrir_caja" role="form" method="post" enctype="multipart/form-data" style="display: none">
                  <div class="row">
                    <div class="form-group col-md-9 col-sm-12 col-xs-12">
                        <label class="col-sm-5">Fecha de apertura</label>
                        <input type="text"  id="acaj_doc_fecha"  name="acaj_doc_fecha" class="validate" value="<?php echo date('Y-m-d H:i:s'); ?>" readonly>
                    </div>
                    <div class="form-group col-md-9 col-sm-12 col-xs-12">
                        <label class="col-sm-5">Monto inicial</label>
                        <input type="text" name="acaj_monto_inicial" id="acaj_monto_inicial" pattern="[0-9]+\.?[0-9]{0,9}" value="" data-type="currency" placeholder="$ 0.00" class="validate t_der t_der_total input-sm" autocomplete="off" required>
                    </div>
                    <div class="form-group col-sm-8 col-sm-offset-4 col-xs-12">
                        <input type="hidden" name="acaj_user_id" id="acaj_user_id" value="<?php echo $_SESSION["userid"]; ?>">
                        <input type="hidden" name="acaj_cierre_id" id="acaj_cierre_id" value="<?php echo $_SESSION["cierre_id"]; ?>">
                        
                        <input type="submit" class="btn btn-success " value="Guardar (Iniciar caja)" id="guardar" name style="color: white;" />
                    </div>
                  </div>

                </form>
                <form action="controlador/accion_caja_cerrar.php" role="form" method="post" enctype="multipart/form-data"  id="form_usar_caja" style="display: none">
                  <div class="row" id="frag_datos">
                    <div class="form-group col-md-4 col-sm-4 col-xs-12">
                        <label >Fecha de apertura</label>
                        <input type="text"  id="usacaj_fecha" class="validate" readonly>
                    </div>
                    <div class="form-group col-md-4 col-sm-4 col-xs-12">
                        <label >Monto inicial</label>
                         <input type="text"  id="usacaj_monto" class="validate" readonly>
                    </div>
                    <div class="form-group col-md-4 col-sm-4 col-xs-12">
                        <label >Ventas</label>
                         <input type="text"  id="usacaj_ventas" class="validate" readonly>
                    </div>
                    <div class="form-group col-sm-8 col-sm-offset-4 col-xs-12" id="frag_botones" >
                        <input type="hidden"  id="usacaj_corteid" name="usacaj_corteid" class="validate" readonly>
                        <br>

                        <button type="button" class="btn btn-success" data-dismiss="modal">Continuar caja</button>
                        <button type="button" class="btn btn-warning" onclick="showDescripcion()">Cerrar caja (Corte)</button>
                    </div>
                  </div>
                  <div class="row" id="frag_descrip" style="display: none">
                        <div class="form-group col-md-9 col-sm-12 col-xs-12">
                            <label class="col-sm-5">Motivo de cierre</label>
                            <input type="text"  id="usacaj_descripcion"  name="usacaj_descripcion" placeholder="Fin de turno, Salida dinero, etc." class="validate input-sm" required />
                            <!--<select name="usacaj_sdescripcion" id="usacaj_sdescripcion" class="form-control selectpicker">
                                <option value="-1">Selecciona un motivo</option>
                                <option>Fin de turno</option>
                                <option>Fin de día</option>
                            </select>-->
                        </div>
                        <div class="form-group col-md-9 col-sm-12 col-xs-12">
                            <label class="col-sm-5">Monto cierre</label>
                            <input type="text" name="usacaj_monto_cierre" id="usacaj_monto_cierre" pattern="[0-9]+\.?[0-9]{0,9}" value="" data-type="currency" placeholder="$ 0.00" class="validate t_der t_der_total input-sm" autocomplete="off" required>
                        </div>

                      <div class="form-group col-sm-8 col-sm-offset-4 col-xs-12">
                            <input type="submit" class="btn btn-success " value="Guardar (Cerrar caja)" id="guardar" name style="color: white;" />
                      </div>
                  </div>
                </form>
              <!-- end metodo de pago -->  
            </div>
            <div class="modal-footer">
                <a href="cajas_usuario.php" class="btn btn-default " >Buscar caja activa</a>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style type="text/css">.validate{ width: 90%; } </style>
<script type="text/javascript">

var rcaja;
$(document).ready(function () {

  validarStatusCaja = function(){

    var refus = $('#acaj_user_id').val();
    var refci = $('#acaj_cierre_id').val();

    //Cargamos los items al select Clientes
    $.post("Ajax/corte_caja.php?op=getUsuarioby",{refuser:refus, refcaja: refci}, function(r){
        rcaja = JSON.parse(r);
        //if (rcaja.tiene_caja != undefined && parseInt(rcaja.tiene_caja) > 0){
        if (rcaja.tiene_caja){
            $("#form_usar_caja").css("display", "block");
            $("#modalabrircaja").html("Usar caja");
            var caja_activa = rcaja.caja.listado[0];
            //for (x in cajas){ console.log(cajas[x])}
            $("#usacaj_corteid").val(caja_activa.id);
            $("#usacaj_fecha").val(caja_activa.apertura);
            $("#usacaj_monto").val(caja_activa.monto_inicial);
            $("#usacaj_ventas").val(rcaja.pagos);
        }else{
            $("#form_abrir_caja").css("display", "block");
            $("#modal_abrircaja").modal('show');
        }
    });
  }

  showDescripcion = function(){
    $("#frag_descrip").css("display", "block");
    $("#frag_botones").css("display", "none");
  }

  //Inicializar
  validarStatusCaja();

});

</script>