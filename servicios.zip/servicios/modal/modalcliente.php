<!-- Modal -->
<div class="modal fade" id="modal_cliente" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" align="center">
                <h3 class="modal-title">Registrar Cliente</h3>
            </div>
            <div class="modal-body">
              
                <form action="controlador/guardar_cliente.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="cm_nombre">Nombre:</label>
                        <input type="text" id="cm_nombre" name="cm_nombre" class="form-control" placeholder="Nombre del cliente" autocomplete="off" onkeyup="mayus(this);" required="" onkeypress="return soloLetras(event)" onblur="limpia()" id="miInput">
                    </div>
                    <div class="form-group">
                        <label for="cm_direccion">Dirección:</label>
                        <input type="text" name="cm_direccion" id="cm_direccion" class="form-control" placeholder="Dirección" required="" onkeyup="mayus(this);" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="cm_telefono">Telefono:</label>
                        <input type="tel" name="cm_telefono" id="cm_telefono" class="form-control" placeholder="Telefono" required="" onkeyup="mayus(this);" autocomplete="off" pattern="[0-9]{10}">
                    </div>

                    <div align="center">
                        <button type="submit" class="btn btn-primary">Registrar</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

function mayus(e) {
    e.value = e.value.toUpperCase();
}

function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    /*
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }*/
}
</script>