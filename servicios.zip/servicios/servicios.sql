-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-03-2020 a las 22:42:11
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `servicios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja`
--

CREATE TABLE `caja` (
  `id_caja` int(11) NOT NULL,
  `numero_caja` int(11) NOT NULL,
  `usuario_caja` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_token` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_completo` varchar(190) COLLATE utf8_spanish_ci NOT NULL,
  `type_user` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `caja`
--

INSERT INTO `caja` (`id_caja`, `numero_caja`, `usuario_caja`, `usuario_token`, `nombre_completo`, `type_user`) VALUES
(2, 1, 'Rosa', '$2y$10$kWQC5UTzseEtQDEM4UtlSejwXUA566ZLjMwrqcsuzgni8ssQm2Fhq', 'Rosa Linares Perez', 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `direccion`, `telefono`) VALUES
(1, 'Juan', 'oxaca sur # 27', '2481590187'),
(2, 'Juan perez', 'sur 30', '66666666');

-- --------------------------------------------------------
--
-- Estructura de tabla para la tabla `cierre_caja`
--

CREATE TABLE `cierre_caja` (
  `id_cierre` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_apertura` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `monto_inicial` decimal(18,2) NOT NULL,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_cierre` decimal(18,2) DEFAULT NULL,
  `descripcion_cierre` varchar(190) COLLATE utf8_spanish_ci NOT NULL,
  `importe_total_venta` decimal(18,2) DEFAULT NULL,
  `id_caja` int(11) NOT NULL,
  PRIMARY KEY (`id_cierre`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_pagos`
--

CREATE TABLE `historial_pagos` (
  `id_historialpagos` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `numero_servivio` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `servicio` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `importe` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;


ALTER TABLE `historial_pagos` 
CHANGE COLUMN `numero_servivio` `numero_servicio` VARCHAR(30) CHARACTER SET 'utf8' NOT NULL ,
CHANGE COLUMN `importe` `importe` DECIMAL(18,2) NOT NULL DEFAULT 0 ,
ADD COLUMN `cantidad` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `importe`,
ADD COLUMN `comision` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `cantidad`,
ADD COLUMN `cobro_extra` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `comision`,
ADD COLUMN `total` DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER `cobro_extra`,
ADD COLUMN `cierre_id` INT NULL AFTER `fecha`;


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servi`
--

CREATE TABLE `servi` (
  `id_servicio` int(3) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `numero_servicio` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_cliente` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

ALTER TABLE `servi` 
ADD COLUMN `id_catservicio` VARCHAR(45) NULL AFTER `id_cliente`;


--
-- Volcado de datos para la tabla `servi`
--

INSERT INTO `servi` (`id_servicio`, `nombre`, `numero_servicio`, `id_cliente`) VALUES
(1, 'CFE', '28373636338', 1),
(2, 'TELCEL', '2316543231', 2),
(3, 'VTV', '656454635636', 1),
(4, 'CFE', '78765433456', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE `servicios` (
  `id_servicio` int(3) NOT NULL,
  `nombre_servicio` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`id_servicio`, `nombre_servicio`) VALUES
(1, 'CFE'),
(2, 'TELCEL'),
(3, 'VETV'),
(4, 'Cable');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `caja`
--
ALTER TABLE `caja`
  ADD PRIMARY KEY (`id_caja`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `historial_pagos`
--
ALTER TABLE `historial_pagos`
  ADD PRIMARY KEY (`id_historialpagos`);

--
-- Indices de la tabla `servi`
--
ALTER TABLE `servi`
  ADD PRIMARY KEY (`id_servicio`);

--
-- Indices de la tabla `servicios`
--
ALTER TABLE `servicios`
  ADD PRIMARY KEY (`id_servicio`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `caja`
--
ALTER TABLE `caja`
  MODIFY `id_caja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `historial_pagos`
--
ALTER TABLE `historial_pagos`
  MODIFY `id_historialpagos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `servi`
--
ALTER TABLE `servi`
  MODIFY `id_servicio` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `servicios`
--
ALTER TABLE `servicios`
  MODIFY `id_servicio` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
