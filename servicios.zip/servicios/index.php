<?php
  session_start();
  //var_dump($_SESSION); exit();
  if(empty($_SESSION["user"]) && empty($_SESSION["user"]))
  {
    header('Location: Login/index.php');
    exit();
  }
  //$usuario =  $_SESSION["user"];
  //echo "Inicio sesión el usuario : $usuario";
?>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
     <link href="favicon.png" rel="icon">
    <title>Servicios</title>
</head>
<body>

    <?php
    include 'menu.php';
    ?>

    <div class="content-wrapper">
        <div class="panel panel-success">
            <div class="panel-heading" align="center">
                <h2>Pago de servicios
                <?php  if(isset($_SESSION["cierre_id"])){
                    echo " <br> <p style='font-size: 0.9rem;'>Caja: <strong>" .date('YCJ'). $_SESSION["cierre_id"]."</strong> </p> ";  }  ?>
                </h2>
            </div>

            <?php  /****   segmento para buscar producto  ****/ ?>
            <div class="panel-body">

                <form action="controlador/guardar_pago.php" role="form" method="post" autocomplete="off" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-4 col-sm-9 col-xs-12">
                            <label>Cliente</label>
                            <select name="p_selectcliente" id="p_selectcliente" class="form-control selectpicker" data-live-search="true" required></select>
                            <input type="hidden" name="nombre_cliente" id="nombre_cliente" readonly />
                            <input type="hidden" name="cierreref" id="cierreref" readonly value="<?php echo $_SESSION["cierre_id"]; ?>" />
                        </div>
                        <div class="form-group col-md-8 col-sm-10 col-xs-12">
                            <div class="row">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <label>Dirección</label>
                                    <input type="text" name="direccion" id="direccion" class="form-control input-sm" placeholder="Dirección" readonly />
                                </div>
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <label>Teléfono</label>
                                    <input type="text" class="form-control input-sm" id="telefono" placeholder="telefono" name="telefono" readonly />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4 col-sm-9 col-xs-12">
                            <label>Servicio</label>
                            <div id="comboServicios"></div>
                        </div>
                        <div class="form-group col-md-8 col-sm-10 col-xs-12">
                            <div class="row">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <label>Número de servicio</label>
                                    <input type="text" name="numero_servicio" class="form-control input-sm" id="numero_servicio" readonly />
                                </div>
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <label>Fecha de pago</label>
                                     <input type="text" name="fecha" class="form-control input-sm" id="fecha" value="<?php echo date(" Y-m-d");?>" readonly />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-2 col-sm-2 col-xs-12">
                            <label>Unidad</label>
                            <input type="text" id="cantidad" name="cantidad"  placeholder="0.00" class="form-control input-sm" required />
                        </div>
                        <div class="form-group col-md-4 col-sm-4 col-xs-12">
                            <label>Importe</label>
                            <input type="text" id="importe" name="importe" placeholder="0.00" class="form-control input-sm"  required />
                        </div>
                        <div class="form-group col-md-3 col-sm-3 col-xs-12">
                            <label>Comision</label>
                            <input type="text" name="comision" id="comision" placeholder="0.00" class="form-control input-sm"  required />
                        </div>
                        <div class="form-group col-md-3 col-sm-3 col-xs-12">
                            <label>Cobro Extra</label>
                            <input type="text" name="cobro_extra"  id="cobro_extra" placeholder="0.00" class="form-control input-sm"  required />
                        </div>
                    </div>
                    <div class="row">
                        <div style="text-align: right; margin-right: 5%; font-size: 4em; margin-top: 20px;">
                            <strong>Total: </strong>    
                            <span class="total" id="totales">$ 0.00</span>
                            <input type="hidden" name="pago_total" id="pago_total" readonly />
                        </div>
                        <div align="center">
                            <button class="btn btn-primary" onclick="return validarFormulario();">Guardar</button>
                        </div>
                    </div>
                </form>
            </div><!--end panel-body-->

            <!--
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
            -->
            
            <script src="js/bootstrap/jquery.3.4.min.js"></script>
            <script src="lib/bootstrap/js/bootstrap.min.js"></script>
            <link rel="stylesheet" href="css/bselect/bootstrap-select.min.css">
            <script src="css/bselect/bootstrap-select.min.js"></script>

            <?php
            include 'modal/modalcliente.php';
            include 'modal/modalservicio.php';
            include 'modal/modalclienteservicio.php';
            include 'modal/modal_abrircaja.php';
            ?>
        </div><!--end panel-->
    </div> <!--end wraper-->
    <!-- jQuery UI -->
    <style type="text/css"> 
      .hidden {display: none;}.minw { margin-left: 1px; margin-right: 20px; } 
    </style>
    <!--
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="js/buscar_clientes.js"></script>
    -->
    <link rel="stylesheet" href="js/jqueryui/jquery-ui.css">
    <script src="js/jqueryui/jquery-ui.min.js"></script>
    <script src="js/buscar_clientes.js"></script>
    <script src="js/calcular_total.js"></script>
    <script type="text/javascript">
        function cerrarcja(){  if($("#usacaj_corteid").val()!= undefined && $("#usacaj_corteid").val().trim().length > 0){ $("#modal_abrircaja").modal('show'); }else{ alert("No existe una caja disponible.")} }
    </script>
</body>
</html>
        