<?php 
header('Content-Type: text/html; charset=utf-8');

include "../bd/conexion.php";

if(isset($_POST['sel_id'])){
	//variable de ajax
    $sel_id = $_POST['sel_id'];

    $cadena="<select id='p_selectservicio' name='p_selectservicio' class='form-control'>";

    if(is_numeric($sel_id)) {

       	$query = "SELECT * FROM servi WHERE id_cliente = '".$sel_id."'";
       	
       	$result = mysqli_query($conn,$query);

       	while($row = mysqli_fetch_array($result) ){
	        $cadena=$cadena.'<option value='.$row['id_servicio'].'>'.$row['nombre']. ' - ' .$row['numero_servicio'] .'</option>';
	    }
    }else{
      $cadena=$cadena."<option value='0'>No hay datos</option>";
    }
    
    echo $cadena.'</select>';

}else{
	echo "Datos no encontrados.";
}

/* cerrar la conexión */
$conn->close();
exit;

