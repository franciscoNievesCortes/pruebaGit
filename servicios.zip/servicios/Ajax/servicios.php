

<?php 
header('Content-Type: text/html; charset=utf-8');
$conn = "empty";

include "../bd/conexion.php";

$cliente=isset($_POST["cliente"])? limpiarCadena($_POST["cliente"]):"";

switch ($_GET["op"]){

	case 'getDatosClienteby':
        $result = $conn->query(" SELECT * FROM clientes WHERE id_cliente=".$cliente." ORDER BY nombre, direccion ");
        $data= Array();

 		while ($reg=$result->fetch_object()){
 			$data[]=array(
                "0"=>$reg->nombre,
 				"1"=>$reg->direccion,
 				"2"=>$reg->telefono
 				);
 		}
 		$results = array(
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"cliente"=>$data);
 		echo json_encode($results);

	break;

	case 'selectCliente':
        echo '<option value="-1">Selecciona un cliente</option>';

        $result = $conn->query(" SELECT * FROM clientes  ORDER BY nombre, direccion ");
        while($row = mysqli_fetch_array($result) ){
	        echo '<option value='.$row['id_cliente'].'>'.$row['nombre']. ' - ' .$row['direccion'] .'</option>';
	    }

	break;

	case 'selectServicios':
        echo '<option value="-1">Selecciona un servicio</option>';

        $result = $conn->query(" SELECT * FROM servicios  ORDER BY nombre_servicio ");
        while($row = mysqli_fetch_array($result) ){
	        echo '<option value='.$row['id_servicio'].'>'.$row['nombre_servicio'] .'</option>';
	    }

	break;

}

/* cerrar la conexión */
$conn->close();


?>