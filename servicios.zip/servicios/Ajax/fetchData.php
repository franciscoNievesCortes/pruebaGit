<?php 
header('Content-Type: text/html; charset=utf-8');

include "../bd/conexion.php";

if(isset($_POST['search'])){
	//variable de ajax
    $search = $_POST['search'];

    $query = "SELECT * FROM clientes WHERE nombre like'%".$search."%'";
    $result = mysqli_query($conn,$query);
    
    while($row = mysqli_fetch_array($result) ){
        $response[] = array("value"=>$row['id_cliente'],"label"=>$row['nombre']
        ,"nombre" =>$row['nombre']
    	,"direccion" =>$row['direccion']
    	,"telefono" =>$row['telefono']);
    }

    echo json_encode($response);
}

/* cerrar la conexión */
$conn->close();
exit;


