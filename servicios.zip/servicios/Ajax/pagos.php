<?php 
header('Content-Type: text/html; charset=utf-8');
$conn = "empty";

include "../bd/conexion.php";
include '../controlador/factory/pagos_repository.php';

$usuario_id=isset($_POST["refuser"])? limpiarCadena($_POST["refuser"]):"";

switch ($_GET["op"]){

	case 'getTablaHistorialPagos':

 		$data = busca_pagos_byuser ($usuario_id, $conn);

 		$sttable = "";
		//items de tablas
		foreach ($data["listado"] as $items)  {
		  $renglon =  sprintf("<tr> <td><button class='btn btn-info' onclick='imprimirticket(%u)'>Ticket</button></td>  <td>%s</td>  <td>%s</td>  <td> %s</td> <td> %s</td> <td> $ %s</td> <td> %s</td> <td> %s</td> </tr>", $items["id"], $items["cliente"], $items["fecha"], $items["nombre_servicio"], $items["numero_servicio"], $items["total"],  $items["usuario_caja"],  $items["caja"]);  
		  $sttable = $sttable . $renglon;
		}

 		$rjson= array(
 			"iTotalRecords"=>count($data["listado"]), //enviamos el total registros 
 			"listado"=>$sttable);
 		echo json_encode($rjson);

	break;
}

/* cerrar la conexión */
$conn->close();


?>