

<?php 
header('Content-Type: text/html; charset=utf-8');
$conn = "empty";

include "../bd/conexion.php";
include '../controlador/factory/caja_repository.php';

$usuario_id=isset($_POST["refuser"])? limpiarCadena($_POST["refuser"]):"";
$corteid=isset($_POST["refcaja"])? limpiarCadena($_POST["refcaja"]):"";

switch ($_GET["op"]){

	case 'getCajasPendientes':

 		$data = busca_cajas_abierta_byuser ($usuario_id, $conn);
 		$rjson= array(
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"listado"=>$data);
 		echo json_encode($rjson);

	break;

	case 'getTablaCajasPendientes':

 		$data = busca_cajas_abierta_byuser ($usuario_id, $conn);

 		$folio = date('Y')."CJ";
 		$suma_calculado = date('Y-m-d H:i:s');

 		$sttable = "";
		//items de tablas
		foreach ($data["listado"] as $items)  {
		  $renglon =  sprintf("<tr> <td><button class='btn btn-info' onclick='utilizarcaja(%u)'>Abrir</button></td>  <td>%s</td>  <td>%s</td>  <td>$ %u</td> <td> %s</td> <td> $ %s</td> <td> %s</td> </tr>", $items["id"], $folio. $items["id"], $items["apertura"], $items["monto_inicial"], $items["cajero"], $items["suma_pagos"],  $suma_calculado);  
		  $sttable = $sttable . $renglon;
		}

 		$rjson= array(
 			"iTotalRecords"=>count($data["listado"]), //enviamos el total registros 
 			"listado"=>$sttable);
 		echo json_encode($rjson);

	break;

	case 'setCajaActiva':

 		session_start();
 		$realizado = 0;
 		if(is_numeric($corteid)){
 			$_SESSION["cierre_id"] = $corteid;
 			$realizado = $corteid;
 		}
 		

 		$rjson= array(
 			"iTotalRecords"=>$realizado, //enviamos el total registros 
 			"listado"=>"empty");
 		echo json_encode($rjson);

	break;

	case 'getUsuarioby':
		//esta almacenado el corte?
		$isopencaja = valida_is_caja_abierta ($corteid, $conn);

		if ($isopencaja){
			$pagos = busca_corte_sumatotal_by_cierreid($corteid, $conn);
			$pagos_total = $pagos["pagos_total"];
			$caja = busca_datos_caja_by($corteid, $conn);
		}
		//cajas del usuario pendientes
		$listado_cajas = busca_cajas_abierta_byuser ($usuario_id, $conn);

        $rjson = array(
 			"tiene_caja"=>$isopencaja, // tiene cajas abierta
 			"caja"=>$caja,  //aqui la caja
 			"pagos"=>$pagos_total,  //total de pagos de la caja
 			"listado"=>$listado_cajas
 		);
 		echo json_encode($rjson);

	break;

}

/* cerrar la conexión */
$conn->close();


?>