<?php 

	/*  esta abierta la caja?  */
	function valida_is_caja_abierta ($corteid, $conn){

		$consulta=$conn->query("SELECT COUNT(*) AS abierta_caja FROM cierre_caja  WHERE id_cierre='".$corteid."' AND (fecha_cierre  IS NULL) ");
	    $row = $consulta->fetch_assoc();
	    return $row['abierta_caja'] > 0 ? True : False;
	}

	/** buscar movimientos de caja  - solo cobros **/
	function busca_corte_sumatotal_by_cierreid($corteid, $conn){
		 /*solo consulta la suma del corte id*/
		 $sql = "SELECT IFNULL(round(SUM(h.total), 2),0)  As pagos_total FROM cierre_caja AS c INNER JOIN historial_pagos AS h ON c.id_cierre = h.cierre_id  WHERE c.id_cierre = '" . $corteid ."' ";
		 //echo $sql;
	  	$result = $conn->query($sql); 

		$row = $result->fetch_assoc();
		$v_total = $row['pagos_total'];

		//crea array 
		$corte = array(
		    "pagos_total" =>  $v_total,
		    "id_cierre" =>    $corteid,
		); 
	 
	  	return $corte;
	}

	//Historial de movimientos
	function  busca_datos_caja_by($corteid, $conn){
		//buscar documento id_cierre
		$consulta=$conn->query("SELECT 0 AS suma_pagos, c.id_cierre, c.id_caja, c.fecha_apertura, c.monto_inicial, c.fecha_cierre, c.monto_cierre, c.descripcion_cierre,  c.importe_total_venta, u.nombre_completo FROM cierre_caja c
    		INNER JOIN caja u ON c.id_caja = u.id_caja  WHERE id_cierre='".$corteid."' ");
		return rellenarlistado($consulta);
	}

	//Historial de movimientos
	function  busca_cajas_abierta_byuser ($usuario_id, $conn){
		//buscar por usuario
		$consulta=$conn->query(" SELECT IFNULL(round(SUM(h.total), 2),0)  As suma_pagos, c.id_cierre, c.id_caja, c.fecha_apertura, c.monto_inicial, c.fecha_cierre, c.monto_cierre, c.descripcion_cierre,  c.importe_total_venta, u.nombre_completo 
			   FROM cierre_caja c 
			     INNER JOIN caja u ON c.id_caja = u.id_caja 
			     LEFT JOIN historial_pagos AS h ON c.id_cierre = h.cierre_id 
			   WHERE c.id_caja='".$usuario_id."' AND  (c.fecha_cierre  IS NULL)
			 GROUP BY c.id_cierre, c.id_caja, c.fecha_apertura, c.monto_inicial, c.fecha_cierre, c.monto_cierre, c.descripcion_cierre,  c.importe_total_venta, u.nombre_completo ");
		return rellenarlistado($consulta);
	}

	//Crea el listado
	function rellenarlistado($consulta){
		//crea array 
		$listado = array();  
		while($filas=$consulta->fetch_assoc()){
		  //ALMACENA EL OBJETO EN EL ARRAY 
		  $myitem = array(
		    "id" =>         $filas['id_cierre'],
		    "cajaid" =>      $filas['id_caja'],
		    "apertura" =>      $filas['fecha_apertura'],
		    "fecha_cierre" =>    $filas['fecha_cierre'],
		    "monto_inicial" =>   $filas['monto_inicial'],
		    "monto_cierre" =>      $filas['monto_cierre'],
		    "descripcion_cierre" => $filas['descripcion_cierre'],
		    "pagos" => $filas['importe_total_venta'],
		    "cajero" => $filas['nombre_completo'],
		    "suma_pagos" => $filas['suma_pagos'] 
		  ); 
		  //agregamos el listado
		  $listado[]=$myitem;
		}
	    //crea array 
		$cajas = array(
		    "cuenta" =>  count($listado),
		    "listado" =>    $listado,
		); 
		return $cajas;
	}

 ?>