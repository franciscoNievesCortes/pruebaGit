<?php 

  	//Historial de movimientos
	function  busca_pagos_byuser ($usuario_id, $conn){
		//buscar por usuario
		$consulta=$conn->query(" SELECT h.id_historialpagos As pagoid, h.nombre AS cliente, h.fecha, h.numero_servicio, s.nombre_servicio, h.importe, h.cantidad, h.comision, h.cobro_extra, h.total, c.id_cierre, concat(YEAR(fecha_apertura),'CJ-',c.id_cierre) AS caja_folio, c.id_caja, c.fecha_apertura, c.monto_inicial, u.usuario_caja, u.nombre_completo 
		   FROM historial_pagos h 
			 INNER JOIN servicios AS s ON s.id_servicio = h.servicio 
			 INNER JOIN cierre_caja AS c ON c.id_cierre = h.cierre_id 
			 INNER JOIN caja u ON c.id_caja = u.id_caja 
		  WHERE c.id_caja='".$usuario_id."' ");
		return rellenarlistado($consulta);
	}

	//Crea el listado
	function rellenarlistado($consulta){
		//crea array 
		$listado = array();  
		//$folio = date('Y')."CJ";
		while($filas=$consulta->fetch_assoc()){
		  //ALMACENA EL OBJETO EN EL ARRAY 
		  $myitem = array(
		    "id" =>         $filas['pagoid'],
		    "cliente" =>      $filas['cliente'],
		    "fecha" =>      $filas['fecha'],
		    "nombre_servicio" =>    $filas['nombre_servicio'],
		    "numero_servicio" =>   $filas['numero_servicio'],
		    "total" =>      $filas['total'],
		    "usuario_caja" => $filas['usuario_caja'],
		    "caja" => $filas["caja_folio"]
		  ); 
		  //agregamos el listado
		  $listado[]=$myitem;
		}
	    //crea array 
		$cajas = array(
		    "cuenta" =>  count($listado),
		    "listado" =>    $listado,
		); 
		return $cajas;
	}


 ?>