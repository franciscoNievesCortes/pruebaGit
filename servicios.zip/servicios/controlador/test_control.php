<?php 
 session_start();
//var_dump($_SESSION); exit();
if(empty($_SESSION["user"]) && empty($_SESSION["user"]))
{
	header('Location: ../Login/index.php');
	exit();
}

//Validar pruebas unitarias
include '../bd/conexion.php';
include 'factory/caja_repository.php';

$corteid = 9;
$usuario_id = 2;

//prueba 1
test_validar_cajas_disponibles($conn, $usuario_id);

echo "<hr> <br>";
//prueba 2
test_validar_estatus_caja($conn, $corteid, $usuario_id);

/* cerrar la conexión */
$conn->close();

//////////////////////////////////////////////////////////////////

function test_validar_cajas_disponibles($conn, $usuario_id){
  	
  	session_start();
  	echo "Tabla de cajas por usuario <br>";

	$data = busca_cajas_abierta_byuser ($usuario_id, $conn);

	$sttable = "";
	//items de tablas
	foreach ($data["listado"] as $items)  {
	  $renglon =  sprintf("<tr> <td>%s</td>  <td>%s</td>  <td>$ %u</td> <td> %s</td> </tr>", $items["id"], $items["apertura"], $items["monto_inicial"], $items["cajero"]);  
	  $sttable = $sttable . $renglon;
	}

	echo $sttable;
}

function test_validar_estatus_caja($conn, $corteid, $usuario_id){

	$isopencaja = valida_is_caja_abierta ($corteid, $conn);
	echo "$isopencaja  <br>";

	if ($isopencaja){
		$pagos = busca_corte_sumatotal_by_cierreid($corteid, $conn);
		$pagos_total = $pagos["pagos_total"];
		echo " pagos_total: $pagos_total <br> ";
		$caja = busca_datos_caja_by($corteid, $conn);
		echo var_dump($caja);
		echo " <br>";
	}else{
		echo "Caja cerrada <br>";
	}

	echo "Lista disponibles <br>";
	$cajas = busca_cajas_abierta_byuser ($usuario_id, $conn);
	echo "<hr> <br>";
	echo var_dump($cajas);
}


///////////////////////////////////////////////////////////






 ?>