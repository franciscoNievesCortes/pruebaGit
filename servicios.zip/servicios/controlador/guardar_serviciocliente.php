<?php

echo "validando";
if (isset($_POST['cs_selectcliente']) && isset($_POST['cs_selectservicio']) ) {
	$cliente = $_POST['cs_selectcliente'];
	$servicios = $_POST['cs_selectservicio'];
	$numero_servicio = $_POST['cs_numero_servicio'];
 
    include '../bd/conexion.php';

    $result = $conn->query(" SELECT * FROM servicios WHERE id_servicio = ".$servicios);
	$nombre_servicio = "";
	while($row = mysqli_fetch_array($result) ){
		$nombre_servicio = $row['nombre_servicio'];
		break;
	}

	$query = $conn -> query ("INSERT INTO `servi` (`nombre`, `numero_servicio`, `id_cliente`, `id_catservicio`) VALUES ('$nombre_servicio', '$numero_servicio', '$cliente', '$servicios'); ");

	if ($query == true) {
		echo"<SCRIPT> alert ('Registro exitoso');
		  window.location.replace('../index.php');
		</SCRIPT>";
	}else{
		echo"<SCRIPT> alert ('Error al insertar');
		  window.location.replace('../index.php');
		</SCRIPT>";
	}

    /* cerrar la conexión */
	$conn->close();
	
}