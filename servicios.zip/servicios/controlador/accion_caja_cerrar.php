<!DOCTYPE html>
<html>
<head>
	<title>Cerrar caja</title>
</head>
<body>

	<h1>Cerrar caja</h1>
	<br>
	<a href="../index.php" class="btn-large waves-effect waves-light green-light">Inicio</a>
	<br> 
	<?php 
	  if (isset($_POST)){
		//$_SESSION["cierre_id"]=0;
		session_start();

     	// iniciar conexion
		include '../bd/conexion.php';
		include 'factory/caja_repository.php';

		//var_dump($_POST);
		$corte_id = isset($_POST["usacaj_corteid"])? limpiarCadena($_POST["usacaj_corteid"]):"";
		$descripcion_cierre = isset($_POST["usacaj_descripcion"])? limpiarCadena($_POST["usacaj_descripcion"]):"";
		$monto_cierre =  isset($_POST["usacaj_monto_cierre"])? limpiarCadena($_POST["usacaj_monto_cierre"]):"";

		//suma pagos
		$cobros = busca_corte_sumatotal_by_cierreid($corte_id, $conn); 
		$monto_cierre   = normalizeDecimal($monto_cierre);
		$pagos_total   =  normalizeDecimal($cobros["pagos_total"]);
		$folio = date("Ymd")."-".$corte_id;
		printf("Caja con folio %s <br>  Fecha: %s <br> Monto cierre: %u <br> Pagos: %u <br> ",$folio,date("Y-m-d H:i:s"),$monto_cierre,$pagos_total );
		//actualizar corte de caja
		$respuesta = $conn->query ("UPDATE cierre_caja
		          SET `fecha_cierre` = '".date("Y-m-d H:i:s")
		              ."', `monto_cierre` = '".$monto_cierre
		              ."', `descripcion_cierre`= '".$descripcion_cierre
		              ."', `importe_total_venta` = '".$pagos_total 
		            ."' Where `id_cierre` = " . $corte_id . "; ");
		echo ($respuesta); 
		if ($respuesta){

		    $_SESSION["cierre_id"]=0;
			echo"<SCRIPT> 
			   alert ('Realizado.');
			   window.location.href = '../index.php?cerrado=true';
			  </SCRIPT>";
		}else{
			echo"<SCRIPT> alert ('Error al insertar');
			document.location=('../index.php');
			</SCRIPT>";
		}

		/* cerrar la conexión */
		$conn->close();


	  }else{
			echo"<SCRIPT> alert ('Información no encontrado.');
			document.location=('../index.php');
			</SCRIPT>";
		}
	?>

 </body>
</html>