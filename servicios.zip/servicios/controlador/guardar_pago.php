<h1>Realizar pago</h1>
<br>
<a href="../index.php" class="btn-large waves-effect waves-light green-light">Inicio</a>
<br> 
<?php 
	if (isset($_POST)){

		// iniciar conexion
		include '../bd/conexion.php';

		//var_dump($_POST); exit();
		$cliente=isset($_POST["p_selectcliente"])? limpiarCadena($_POST["p_selectcliente"]):"";
		$nombre_cliente=isset($_POST["nombre_cliente"])? limpiarCadena($_POST["nombre_cliente"]):"";
		$direccion=isset($_POST["direccion"])? limpiarCadena($_POST["direccion"]):"";
		$telefono=isset($_POST["telefono"])? limpiarCadena($_POST["telefono"]):"";

		$servicio=isset($_POST["p_selectservicio"])? limpiarCadena($_POST["p_selectservicio"]):"";
		$numero_servicio=isset($_POST["numero_servicio"])? limpiarCadena($_POST["numero_servicio"]):"";
		//$fecha=isset($_POST["fecha"])? limpiarCadena($_POST["fecha"]):"";
		$fecha = date("Y-m-d H:m:s");
		$cantidad=isset($_POST["cantidad"])? limpiarCadena($_POST["cantidad"]):"";
		$importe=isset($_POST["importe"])? limpiarCadena($_POST["importe"]):"";
		$comision=isset($_POST["comision"])? limpiarCadena($_POST["comision"]):"";
		$cobro_extra=isset($_POST["cobro_extra"])? limpiarCadena($_POST["cobro_extra"]):"";
		$pago_total=isset($_POST["pago_total"])? limpiarCadena($_POST["pago_total"]):"";

		$cierre_id=isset($_POST["cierreref"])? limpiarCadena($_POST["cierreref"]):"";

		$query = $conn -> query ("INSERT INTO historial_pagos (cierre_id, nombre, direccion, telefono, fecha, numero_servicio, servicio, importe, cantidad, comision, cobro_extra, total) 
			    VALUES('$cierre_id', '$nombre_cliente', '$direccion', '$telefono', '$fecha', '$numero_servicio', '$servicio', '$importe', '$cantidad', '$comision', '$cobro_extra', '$pago_total'); ");

		if ($query == true) {

			// Print auto-generated id
			$newid = $conn -> insert_id;

			//window.open('ticket.php?coded=$newid', '_blank');
			//window.location.href = 'ticket.php?coded=$newid';

			echo"<SCRIPT> alert ('Pago realizado.');
			   window.open('../ticket.php?coded=$newid', '_blank');
			   window.location.replace('../index.php?coded=$newid');
			</SCRIPT>";
		}else{
			echo"<SCRIPT> alert ('Error al insertar');
			   window.location.replace('../index.php');
			</SCRIPT>";
		}

		/* cerrar la conexión */
		$conn->close();


	}else{
			echo"<SCRIPT> alert ('Información no encontrado.');
			  window.location.replace('../index.php');
			</SCRIPT>";
		}

 ?>

