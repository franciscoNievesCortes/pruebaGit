<?php 
   
   // iniciar conexion
	include '../bd/conexion.php';

	$user=isset($_GET["refuser"])? limpiarCadena($_GET["refuser"]):"";

	/*solo consulta la suma del corte id*/
	$sql = "SELECT id_caja, usuario_caja FROM caja WHERE usuario_caja='$user' "; 
	//echo $sql;
	$consulta=$crud->do_select($sql);
	$rowcount = mysqli_num_rows($consulta); 
	//echo "string".$rowcount;
	$user_id = 0;
	if($rowcount > 0){
		$row = $consulta->fetch_assoc();
		$user_id = $row['id_caja'];
	} 


 ?>