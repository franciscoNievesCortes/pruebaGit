<?php
if (isset($_POST)){

	include '../bd/conexion.php';

	$nombre = $_POST['cm_nombre'];
	$direccion = $_POST['cm_direccion'];
	$telefono = $_POST['cm_telefono'];

	//$num_servicio = $_POST['num_servicio'];
	 $query = $conn -> query ("INSERT INTO `clientes` (`nombre`, `direccion`, `telefono`) VALUES ('$nombre', '$direccion', '$telefono');");

	 if ($query == true) {
	 	echo"<SCRIPT> alert ('Registro exitoso');
			window.location.replace('../index.php');
			</SCRIPT>";
	 }else{
	 	echo"<SCRIPT> alert ('Error al registrar');
			window.location.replace('../index.php');
			</SCRIPT>";
	 }
}else{
	echo"<SCRIPT> alert ('Error al registrar');
			window.location.replace('../index.php');
			</SCRIPT>";
}

?>