<?php

include '../bd/conexion.php';

$nombre_servicio = $_POST['nombre_servicio'];
//echo "$nombre";

 $query = $conn -> query ("INSERT INTO `servicios` (`nombre_servicio`) VALUES ('$nombre_servicio');");


 if ($query == true) {
 echo"<SCRIPT> alert ('Registro exitoso');
		window.location.replace('../index.php');
		</SCRIPT>";
 }else{
 	echo"<SCRIPT> alert ('No se guardo servicio.');
		window.location.replace('../index.php');
		</SCRIPT>";
 }

/* cerrar la conexión */
$conn->close();

?>