<!DOCTYPE html>
<html>
<head>
	<title>Abrir caja</title>
</head>
<body>


<h1>Abrir caja</h1>
<br>
<a href="../index.php" class="btn-large waves-effect waves-light green-light">Inicio</a>
<br> 
<?php 
	if (isset($_POST)){
		session_start();

		// iniciar conexion
		include '../bd/conexion.php';

		//var_dump($_POST);
		$fecha=isset($_POST["acaj_doc_fecha"])? limpiarCadena($_POST["acaj_doc_fecha"]):"";
		$monto_inicial=isset($_POST["acaj_monto_inicial"])? limpiarCadena($_POST["acaj_monto_inicial"]):"";
		$id_caja = isset($_POST["acaj_user_id"])? limpiarCadena($_POST["acaj_user_id"]):"";
		$descripcion_cierre = "-";
		$monto_cierre = 0;
		$importe_venta = 0;

		$query = $conn -> query ("INSERT INTO `cierre_caja` (`fecha_apertura`, `monto_inicial`, `descripcion_cierre`,  `monto_cierre`,  `importe_total_venta`, `id_caja`) 
					VALUES ('$fecha', '$monto_inicial', '$descripcion_cierre', '$monto_cierre', '$importe_venta', '$id_caja'); ");

		if ($query == true) {

			// Print auto-generated id
			$newid = $conn-> insert_id;
			$_SESSION["cierre_id"]=$newid;

			//window.open('ticket.php?coded=$newid', '_blank');
			//window.location.href = 'ticket.php?coded=$newid';

			echo"<SCRIPT> 
			   window.location.href = '../index.php?inicaja=$monto_inicial';
			  </SCRIPT>";
		}else{
			echo"<SCRIPT> alert ('Error al insertar');
			document.location=('../index.php');
			</SCRIPT>";
		}

		/* cerrar la conexión */
		$conn->close();


	}else{
			echo"<SCRIPT> alert ('Información no encontrado.');
			document.location=('../index.php');
			</SCRIPT>";
		}

 ?>

 </body>
</html>