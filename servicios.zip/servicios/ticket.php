<?php
include "fpdf/fpdf.php";
include 'bd/conexion.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$ticketid=isset($_GET["coded"])? limpiarCadena($_GET["coded"]):"";

$sql = "SELECT id_historialpagos, nombre, direccion, telefono, fecha, numero_servicio, servicio, s.nombre_servicio, importe, cantidad, comision, cobro_extra, total FROM historial_pagos INNER JOIN servicios AS s ON s.id_servicio = historial_pagos.servicio WHERE `id_historialpagos` = $ticketid ; ";

$result = $conn->query($sql);
if($result->num_rows < 1){
	echo"<SCRIPT> alert ('Error al identificar ticket');
			document.location=('index.php');
			</SCRIPT>";
	exit();
}
if($row = $result->fetch_array())
{
    $id = $row['id_historialpagos'];
    $nombre = $row['nombre'];
	$direccion = $row['direccion'];
	$telefono = $row['telefono'];
	$fecha = $row['fecha'];
	$numero_servicio = $row['numero_servicio'];
	$servicio = $row['servicio'];
	$nombre_servicio = $row['nombre_servicio'];
	$importe = $row['importe'];
	$cantidad = $row['cantidad'];
	$comision = $row['comision'];
	$cobro_extra = $row['cobro_extra'];
	$total = $row['total'];
}
//echo $total;

//$text = "la niña juega en un árbol.";
//$text2 = iconv("UTF-8", "ISO-8859-1", $text);
//echo $text2;


$pdf = new FPDF($orientation='P',$unit='mm', array(45,350));
header('Content-Type: text/html; charset=ISO-8859-1');

$pdf->AddPage();
$pdf->SetFont('Arial','B',9);    //Letra Arial, negrita (Bold), tam. 20
$textypos = 9;

$pdf->setY(2);
$pdf->setX(2);
 $pdf->Cell(40,10," Proveedor de servicios",0,0,'C');
$textypos = 17;

$pdf->setX(2);
$pdf->Cell(5,$textypos,iconv("UTF-8", "ISO-8859-1", "          Informáticos "));

$textypos = 27;

$pdf->setX(2);
$pdf->Cell(5,$textypos,"       OAXACA NTE 1-1");

   //Letra Arial, negrita (Bold), tam. 20
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'-------------------------------------');


$textypos+=12;
$pdf->setX(2);
  
$pdf->SetFont('Arial','',8); 
$pdf->Cell(5,$textypos,iconv("UTF-8", "ISO-8859-1",'Nombre: '.$nombre.''));
$textypos+=9;
$pdf->setX(2);
$pdf->Cell(5,$textypos,iconv("UTF-8", "ISO-8859-1",'Dirección: '.$direccion.''));
$textypos+=9;
$pdf->setX(2);
$pdf->Cell(5,$textypos,iconv("UTF-8", "ISO-8859-1",'Teléfono: '.$telefono.''));
$textypos+=9;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'Fecha: '.$fecha.'');
$textypos+=9;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'Servicio:   '.$nombre_servicio);
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,iconv("UTF-8", "ISO-8859-1",'Número de servicio: '));
$textypos+=9;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'           '.$numero_servicio.'');
$textypos+=9;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'Cantidad:   '.$cantidad.' x');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'Importe:    $'.$importe.'');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,iconv("UTF-8", "ISO-8859-1",'Comisión:   ').$comision.' %');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'Extra:       +$'.$cobro_extra.'');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'-------------------------------------');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'Total:         $'.$total.'');
$textypos+=6;
$pdf->setX(2);
$pdf->Cell(5,$textypos,'-------------------------------------');

//Generar pdf
$pdf->Output();
