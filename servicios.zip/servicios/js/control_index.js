
// JavaScript source code

$(document).ready(function () {

    $('#comboServicios').on('change', function () {
        //alert( $(this).find(":selected").val() );
        displayServicio();
    });

    $("#selectuser_id").focusout(function () {
        if ($('#autocomplete_texto').val() === "") {
            alert("Debes escribir un nombre.");
        }
    });
    //set
    setupId();
});

function setupId() {
    if ($('#selectuser_id').val() != undefined) {
        loadservicios($('#selectuser_id').val());
    }
}

function loadservicios(selid) {
    console.log("buscando...")
    $.ajax({
        type: "POST",
        url: "Ajax/cargarServicios.php",
        data: "sel_id=" + selid,
        success: function (r) {
            console.log("lserv")
            $('#comboServicios').html(r);
            displayServicio();
        }
    });
}

function displayServicio() {
    var selectItem = $('#comboServicios').find(":selected").text();
    //console.log(selectItem.split(" - ")[1]);
    $('#numero_servicio').val(selectItem.split(" - ")[1]);
    document.getElementById("lista2").style.maxWidth = "145px";
}

$(function () {
    $("#autocomplete_texto").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "Ajax/fetchData.php",
                type: 'post',
                dataType: "json",
                data: {
                    search: request.term
                },
                success: function (data) {
                    response(data);
                }
            });
        },
        select: function (event, ui) {
            $('#autocomplete_texto').val(ui.item.label); // display the selected text
            $('#selectuser_id').val(ui.item.value); // save selected id to input
            $('#direccion').val(ui.item.direccion);
            $('#telefono').val(ui.item.telefono);
            loadservicios(ui.item.value)//load seervicios
            return false;
        }
    });
    // end select
});

function split(val) {
    return val.split(/,\s*/);
}
function extractLast(term) {
    return split(term).pop();
}

$(function () {
    $("#nombre").autocomplete({
        source: "Ajax/clientes1.php",
        minLength: 2,
        select: function (event, ui) {
            console.log('c_selected')
            alert('You selected: ' + ui.value + ', ' + ui.data);
            event.preventDefault();

            var id_cliente = $('#id_cliente');
            $('#nombre').val(ui.item.nombre);
            $('#direccion').val(ui.item.direccion);
            $('#telefono').val(ui.item.telefono);
            //$('#numero_servicio').val(ui.item.numero_servicio);
        }
    });
});



$(document).ready(function () {
    $(".grupo").keyup(function () {
        var unidad = $(this).find("input[name=unidad]").val();
        var importe = $(this).find("input[name=importe]").val();
        var cantidad = $(this).find("input[name=cantidad]").val();
        var cobro_extra = $(this).find("input[name=cobro_extra]").val();

        $(this).find("[class=total]").html(parseInt(unidad) * parseInt(importe) + parseInt(cantidad) + parseInt(cobro_extra));
        // calculamos el total de todos los grupos
        var total = 0;
        $(".grupo .total").each(function () {
            total = total + parseInt($(this).html());
        })
        $(".total .total").html(total);
    });
});


