

$(document).ready(function () {

	var refc = $('#refuser').val();
    $.post("Ajax/corte_caja.php?op=getTablaCajasPendientes",{refuser:refc}, function(r){
        var datosc = JSON.parse(r);
        //cajas = datosc;
        if(datosc.iTotalRecords != undefined){
            //console.log(datosc.cliente[0])
            $("#listado").html(datosc.listado);
        }
    });

    utilizarcaja = function(caja){

    	$.post("Ajax/corte_caja.php?op=setCajaActiva",{refcaja:caja}, function(r){
	        var datosc = JSON.parse(r);
	        //cajas = datosc;
	        if(datosc.iTotalRecords != undefined){
	            //console.log(datosc.cliente[0])
	            window.location.href = "index.php";
	        }
	    });
	}

});