

$(document).ready(function () {

	var refc = $('#refuser').val();
    $.post("Ajax/pagos.php?op=getTablaHistorialPagos",{refuser:refc}, function(r){
        var datosc = JSON.parse(r);
        //cajas = datosc;
        if(datosc.iTotalRecords != undefined){
            //console.log(datosc.cliente[0])
            $("#listado").html(datosc.listado);
        }
    });

    imprimirticket = function(pago){

        window.open("ticket.php?coded="+pago, '_blank');
	}

});