$(document).ready(function ($) {

	$('#cantidad').keyup(function (e) {
        mont = $(this).val();
        //console.log(mont);
        if (!validarNumero(mont)){
           $('#cantidad').val("")
        }else
          calcularTablaAmortizacion();
    });
    $('#importe').keyup(function (e) {
        mont = $(this).val();
        //console.log(mont);
        if (!validarNumero(mont)){
           $('#importe').val("")
        }else
          calcularTablaAmortizacion();
    });
    $('#comision').keyup(function (e) {
        mont = $(this).val();
        //console.log(mont);
        if (!validarNumero(mont)){
           $('#comision').val("")
        }else
          calcularTablaAmortizacion();
    });
    $('#cobro_extra').keyup(function (e) {
        mont = $(this).val();
        //console.log(mont);
        if (!validarNumero(mont)){
           $('#cobro_extra').val("")
        }else
          calcularTablaAmortizacion();
    });


    validarFormulario = function(){
        if($("#usacaj_corteid").val()== undefined || $("#usacaj_corteid").val().trim().length == 0){
          validarStatusCaja();
          return false;
        }
        var saldo = calcularTablaAmortizacion();
        if ((saldo != undefined) &&  (saldo > 0)){
             return true;
        }else{
            alert('Valida el saldo a calculado');
            return false;
        }
    }

    calcularTablaAmortizacion = function(){
    	var cantidad = $('#cantidad').val();
        var mont = $('#importe').val();
        var interes = $('#comision').val();
        var cobro_extra = $('#cobro_extra').val();
        var subtotal = parseFloat(cantidad) * parseFloat(mont);
        var subt_interes = parseFloat(subtotal) * (parseFloat(interes) / 100);
        var total = parseFloat(subt_interes) + parseFloat(subtotal) + parseFloat(cobro_extra);
        
        $("#totales").html(convertToDecimalString(total));
        $("#pago_total").val(convertToDecimalString(total));
      /*
        console.log("subtotal:"); console.log(subtotal);
        console.log("total"); console.log(total);
        console.log("subt_interes"); console.log(subt_interes); */
        return total;
    }

    validarNumero = function (__val__, only_money){
        var preg = /^([0-9]+\.?[0-9]{0,9})$/; 
        if (only_money){
            preg = /^([0-9]+\.?[0-9]{0,2})$/; 
        }
        if(preg.test(__val__) === true){
            return true;
        }else{
           return false;
        }
    }

    quitarFormatNumber = function(n) {
        // format number  1,234,567 to 1000000
        var resp = n.replace("$","");
        resp = resp.replace(" ","");
        resp = resp.replace(".","");
        resp = resp.replace(/,/gi,"");
        return resp;
    }

   isnumber_than = function(input, min_num){
        // get input value
        var input_val = input.val();
        if (!isNaN(input_val)){
            if (input_val > min_num){
              return true;
            }
        }
        return false;
    }

    convertToDecimalString = function(input_val){
    // get input value
      input_val = input_val + "";//var input_val = input.val();
       
      // don't validate empty input
      if (input_val === "") { return "0.00"; }
      if (input_val === "NaN") { return "0.00"; }
        
      // check for decimal
      if (input_val.indexOf(".") >= 0) {

        // get position of first decimal
        var decimal_pos = input_val.indexOf(".");

        // split number by decimal point
        var left_side = input_val.substring(0, decimal_pos);
        var right_side = input_val.substring(decimal_pos);

        // add commas to left side of number
        left_side = quitarFormatNumber(left_side);

        // validate right side
        right_side = quitarFormatNumber(right_side);

        // On blur make sure 2 numbers after decimal
        if (right_side === "") {
          right_side += "00";
        }
        
        // Limit decimal to only 2 digits
        if(right_side.length>2){
          right_side = right_side.substring(0, 2);
        }

        // join number by .
        input_val = left_side + "." + right_side;

      } else {
          // no decimal entered
          input_val = quitarFormatNumber(input_val);
          input_val = input_val + ".00";
      }
      return input_val;
    }

});