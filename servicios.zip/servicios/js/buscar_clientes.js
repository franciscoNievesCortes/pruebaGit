


$(document).ready(function () {

    $("#p_selectcliente").change(function (event, ui) {
        setupId();
    });

    $('#comboServicios').on('change', function () {
        //alert( $(this).find(":selected").val() );
        displayServicio();
    });
    $("#cantidad").val("1");
    /*
    $("#importe").val("100");
    $("#comision").val("10");
    $("#cobro_extra").val("0");
    */
    //load
    loadClientes()
    //set
    setupId();
});

function setupId() {
    if ($('#p_selectcliente').val() != undefined && $('#p_selectcliente').val() != "-1") {
        //datos cliente
        detallecliente();
        //load servicios
        loadservicios($('#p_selectcliente').val());
    }else{
        $("#nombre_cliente").val("");
        $("#direccion").val("");
        $("#telefono").val("");
        $('#comboServicios').html('<select  id="p_selectservicio" name="p_selectservicio" class="form-control"><option value="-1">Sin datos</option></select>');
    }
}

function loadservicios(selid) {
    console.log("buscando...")
    $.ajax({
        type: "POST",
        url: "Ajax/cargarServicios.php",
        data: "sel_id=" + selid,
        success: function (r) {
            console.log("lserv")
            $('#comboServicios').html(r);
            displayServicio();
        }
    });
}

function displayServicio() {
    var selectItem = $('#comboServicios').find(":selected").text();
    //console.log(selectItem.split(" - ")[1]);
    $('#numero_servicio').val(selectItem.split(" - ")[1]);
    //    document.getElementById("lista2").style.maxWidth = "145px";
}

function detallecliente(){
    var refc = $('#p_selectcliente').val();
    $.post("Ajax/servicios.php?op=getDatosClienteby",{cliente:refc}, function(r){
        var datosc = JSON.parse(r);
        if(datosc.cliente[0] != undefined){
            //console.log(datosc.cliente[0])
            $("#nombre_cliente").val(datosc.cliente[0][0]);
            $("#direccion").val(datosc.cliente[0][1]);
            $("#telefono").val(datosc.cliente[0][2]);
        }
    });
}

function loadClientes(){
    //Cargamos los items al select Clientes A ventana principal
    $.post("Ajax/servicios.php?op=selectCliente", function(r){
            $("#p_selectcliente").append(r);
            $('#p_selectcliente').selectpicker('refresh');
    });
}

