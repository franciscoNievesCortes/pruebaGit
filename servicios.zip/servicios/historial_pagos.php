<?php
  session_start();
  //var_dump($_SESSION); exit();
  if(empty($_SESSION["user"]) && empty($_SESSION["user"]))
  {
    header('Location: Login/index.php');
    exit();
  }
  //$usuario =  $_SESSION["user"];
  //echo "Inicio sesión el usuario : $usuario";
?>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
     <link href="favicon.png" rel="icon">
    <title>Servicios</title>
</head>
<body>

    <?php
    include 'menu.php';
    ?>

    <div class="content-wrapper">
        <div class="panel panel-info">
            <div class="panel-heading" align="center">
                <h2>Historial de pagos</h2>
            </div>

            <?php  /****  listado de cajas activas ****/ ?>
            <div class="panel-body">
              <input type="hidden" name="refuser" id="refuser" value="<?php echo $_SESSION["userid"]; ?>">
              
              <div class="row" style="margin-left: 1rem 3rem 4rem 3rem; ">
                 <div class="col-md-12 col-sm-12 col-xs-12">
                     <table class="table table-hover">
                      <tr>
                         <th>Opciones</th>
                         <th>Cliente</th>
                         <th>Pago</th>
                         <th>Servicio</th>
                         <th>Número</th>
                         <th>Total</th>
                         <th>Cajero</th>
                         <th>Caja</th>
                      </tr>
                      <tbody id="listado">
                        <tr>
                          <td></td>
                        </tr>

                      </tbody>
                     </table>
                 </div>
              </div>

            </div><!--end panel-body-->

            <script src="js/bootstrap/jquery.3.4.min.js"></script>
            <script src="lib/bootstrap/js/bootstrap.min.js"></script>
            <script src="js/buscar_historial_pagos.js"></script>
        </div><!--end panel-->
    </div> <!--end wraper-->
</body>
</html>
        